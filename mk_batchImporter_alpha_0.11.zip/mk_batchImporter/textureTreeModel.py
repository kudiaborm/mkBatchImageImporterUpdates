import pymel.core as pm
import maya.mel as mel

import PySide.QtCore as QtCore
import PySide.QtGui as QtGui